package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class HomePage {
    WebDriver driver;
    WebDriverWait wait;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void acceptCookies() {
        WebElement gotIt = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(text(),'Got it')]")));
        gotIt.click();
    }

    public void enterLocation(String location) {
        WebElement locationBox = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("bigsearch-query-location-input")));
        locationBox.click();
        locationBox.sendKeys(location);
    }

    public void selectFirstSuggestion() {
        try {
            By suggestionLocator = By.xpath("(//div[@data-testid='option-0'])[1]");
            
            wait.until(ExpectedConditions.elementToBeClickable(suggestionLocator)).click();
        } catch (StaleElementReferenceException e) {
            // Retry once if stale
            WebElement suggestion = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("(//div[@data-testid='option-0'])[1]")));
            suggestion.click();
        }
    }
    public void selectDates() {
        while (true) {
            WebElement monthDate = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("(//div[@aria-label='Calendar']//h2[contains(text(),'June 2025')])[1]")));
            if (monthDate.isDisplayed()) break;
            driver.findElement(By.xpath("(//button[@aria-label='Move forward to change to the next month.'])[1]")).click();
        }

        WebElement checkInDate = driver.findElement(By.xpath("//button[@aria-label='25, Wednesday, June 2025. Available. Select as check-in date.']"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkInDate);

        WebElement checkOutDate = wait.until(ExpectedConditions.presenceOfElementLocated(
            By.xpath("//button[contains(@aria-label,'30, Monday, June 2025')]")));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkOutDate);
    }

    public void selectGuests() {
        WebElement guestButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[contains(text(),'Add guests')]")));
        guestButton.click();

        for (int i = 0; i < 2; i++) {
            WebElement adultBtn = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("(//button[@data-testid='stepper-adults-increase-button'])[1]")));
            adultBtn.click();
            driver.findElement(By.xpath("(//button[@data-testid='stepper-children-increase-button'])[1]")).click();
        }
    }

    public void clickSearch() {
        WebElement searchBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[@data-testid=\"structured-search-input-search-button\"]")));
        searchBtn.click();
    }

    public void applyFilters() throws InterruptedException {
    	 WebElement filter= wait.until(ExpectedConditions.elementToBeClickable(
				 By.xpath("//span[contains(text(),'Filters')]")));
		 filter.click();
		 
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 WebElement scrollableDiv = wait.until(ExpectedConditions.presenceOfElementLocated(
				 By.xpath("//div[@class='stiimno atm_l1_1wugsn5 atm_e2_1osqo2v dir dir-ltr']")));		 
		 
		 // Then scroll to bottom of the element
		 js.executeScript("arguments[0].scrollTop = arguments[0].scrollHeight;", scrollableDiv);
		 
		 WebElement priceInput = new WebDriverWait(driver, Duration.ofSeconds(10))
			        .until(ExpectedConditions.elementToBeClickable(By.id("price_filter_min")));
			// This updates the value and notifies any React/Angular event listeners
			js.executeScript(
			    "arguments[0].value = '5000';" +
			    "arguments[0].dispatchEvent(new Event('input', { bubbles: true }));",
			    priceInput
			);
			
			WebElement priceMax = new WebDriverWait(driver, Duration.ofSeconds(10))
			        .until(ExpectedConditions.elementToBeClickable(By.id("price_filter_max")));
			// This updates the value and notifies any React/Angular event listeners
			js.executeScript(
			    "arguments[0].value = '6000';" +
			    "arguments[0].dispatchEvent(new Event('input', { bubbles: true }));",
			    priceMax
			);
			
			Thread.sleep(2000);
			WebElement Showplaces= wait.until(ExpectedConditions.elementToBeClickable(
					 By.xpath("//div[@class='p13966et atm_7l_1p8m8iw dir dir-ltr']//a[contains(text(),'Show')]")));
			 Showplaces.click();
			 
			 wait.until(ExpectedConditions.presenceOfElementLocated(
		                By.xpath("//div[contains(@class, 'dmzfgqv')]//div[contains(@class, 'gsgwcjk')]/div")
		            ));
			
			 List<WebElement> cards = driver.findElements(
					    By.xpath("//div[contains(@class, 'dmzfgqv')]//div[contains(@class, 'gsgwcjk')]/div")
					);
			 System.out.println("Total cards found: " + cards.size());
			 Thread.sleep(2000);
			 for (int i = 0; i < Math.min(5, cards.size()); i++) {
			     WebElement card = cards.get(i);
			     String[] lines = card.getText().trim().split("\\r?\\n");

			     
			     if (lines.length >= 2) {
			         System.out.println("Title: " + lines[1]);  // second line
			     } else {
			         System.out.println(" Title not found.");
			     }
			 }
}
}