package tests;

import com.aventstack.extentreports.Status;
import org.testng.ITestResult;
import org.testng.annotations.*;
import pages.HomePage;
import utils.ScreenshotUtil;

import java.io.IOException;

public class AirbnbTest extends BaseTest {

    HomePage homePage;

    @BeforeMethod
    public void beforeMethod() {
        test = extent.createTest("Full Airbnb Booking Flow");
        homePage = new HomePage(driver);
    }

    @Test
    public void testFullBookingFlow() throws InterruptedException {
        test.log(Status.INFO, "Accepting cookies...");
        homePage.acceptCookies();

        test.log(Status.INFO, "Entering location...");
        homePage.enterLocation("Lonavala");

        test.log(Status.INFO, "Selecting suggestion...");
        homePage.selectFirstSuggestion();

        test.log(Status.INFO, "Selecting dates...");
        homePage.selectDates();

        test.log(Status.INFO, "Selecting guests...");
        homePage.selectGuests();

        test.log(Status.INFO, "Clicking search...");
        homePage.clickSearch();

        test.log(Status.INFO, "Applying filters...");
        homePage.applyFilters();

        test.log(Status.PASS, "Successfully completed full booking flow.");
    }

 /*   @AfterMethod
    public void afterMethod(ITestResult result) throws IOException {
        if (result.getStatus() == ITestResult.FAILURE) {
            String screenshotPath = ScreenshotUtil.takeScreenshot(driver, result.getName());
            test.fail("Test Failed. Screenshot below:").addScreenCaptureFromPath(screenshotPath);
            logger.error("Test Failed: " + result.getName());
        }
    }*/
}
