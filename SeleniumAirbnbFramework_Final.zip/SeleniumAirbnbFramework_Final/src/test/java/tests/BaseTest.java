package tests;

import com.aventstack.extentreports.ExtentReports;

import com.aventstack.extentreports.ExtentTest;
//import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

public class BaseTest {
    public WebDriver driver;
    public static ExtentReports extent;
    public static ExtentTest test;
    public static Logger logger;

    @BeforeSuite
    public void setupReporting() {
    	ExtentSparkReporter htmlReporter = new ExtentSparkReporter("test-output/ExtentReport.html");
    	htmlReporter.config().setTheme(Theme.STANDARD);
    	htmlReporter.config().setDocumentTitle("Airbnb Automation Report");
    	htmlReporter.config().setReportName("Test Execution Report");

    	extent = new ExtentReports();
    	extent.attachReporter(htmlReporter);

        logger = Logger.getLogger("AirbnbAutomation");
        PropertyConfigurator.configure("src/test/resources/log4j.properties");
    }

    @BeforeClass
    public void setup() throws IOException {
        Properties prop = new Properties();
        FileInputStream fis = new FileInputStream("src/test/resources/data.properties");
        prop.load(fis);
        String browser = prop.getProperty("browser");

        if (browser.equalsIgnoreCase("chrome")) {
            System.setProperty("wedriver.chrome.driver", "E:\\Selenium\\chromedriver-win64");
            driver = new ChromeDriver();
        }

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get(prop.getProperty("url"));

        logger.info("Browser launched and navigated to: " + prop.getProperty("url"));
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
        logger.info("Browser closed.");
    }

    @AfterSuite
    public void tearDownReport() {
        extent.flush();
    }
}
